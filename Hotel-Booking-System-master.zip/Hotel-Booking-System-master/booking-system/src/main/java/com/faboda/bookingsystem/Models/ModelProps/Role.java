package com.faboda.bookingsystem.Models.ModelProps;

public enum Role {

    ADMIN,
    USER
}
