package com.faboda.bookingsystem.Models.ModelProps;

public enum Status {
    CANCELED,
    RESERVED,

}
